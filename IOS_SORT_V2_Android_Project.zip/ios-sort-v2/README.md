# IOS SORT V2 — Android APK build

This is an Android-installable app project (not a browser-only PWA). It packages the offline-first IOS SORT interface inside a native Android Activity, with Android speech recognition bridged to the app.

## Easiest route using only your Samsung phone

1. Create/sign in to a GitHub account in Chrome: https://github.com
2. Create a **public** repository named `ios-sort-v2` (public is the simplest route for GitHub Actions on a free account).
3. On GitHub, choose **Add file → Upload files** and upload the contents of this project ZIP (including the hidden `.github` folder; if the mobile site hides it, use GitHub's web upload in desktop mode or GitHub's mobile app/browser file picker).
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build IOS SORT V2 APK**, tap **Run workflow**, then run it.
6. When the workflow finishes green, open that run, scroll to **Artifacts**, and download `IOS-SORT-V2-debug-APK`.
7. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` and allow Android to install apps from that source if prompted.

The workflow builds the APK on GitHub's cloud runner; no PC or Android Studio is needed. The resulting debug APK is installable, but it is not a Play Store release-signed APK. Keep the APK private if you don't want others installing it.

## Features in V2
- Home dashboard and task focus/progress
- Task categories, priority, due dates, search, completion and deletion
- Quick capture with keyword-based category suggestions
- Native Android speech-to-text (requires microphone permission and a speech recognition service)
- Inventory with quantity, category and status
- Searchable notes/records
- Income and expense log in Nigerian naira
- JSON backup export/import
- Offline local storage; no account or cloud sync

## Build details
- Application ID: `com.iosinstall.iossort`
- Version: `2.0` (versionCode 2)
- Minimum Android: 6.0 (API 23)
- Target/compile SDK: 35
- Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3

## Important limitations
Smart sorting is currently local keyword-based logic, not a cloud AI model. Data is stored on this device and is not synced between devices. Export backups before uninstalling or clearing app data.

### If GitHub's phone uploader cannot show the hidden `.github` folder

Create the repository first, upload this ZIP file into its root as `IOS_SORT_V2_Android_Project.zip`, then use GitHub's **Add file → Create new file** and create `.github/workflows/build-apk.yml`. Paste this workflow (it automatically unpacks the uploaded ZIP):

```yaml
name: Build IOS SORT V2 APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project
        run: |
          unzip -q IOS_SORT_V2_Android_Project.zip
          cp -a ios-sort-v2/. .
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - run: gradle --no-daemon assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: IOS-SORT-V2-debug-APK
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```
