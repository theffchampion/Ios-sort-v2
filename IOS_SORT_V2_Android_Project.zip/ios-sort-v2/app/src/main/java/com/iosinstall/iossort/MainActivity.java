package com.iosinstall.iossort;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 71;
    private static final int AUDIO_PERMISSION = 72;
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(false); s.setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    private class VoiceBridge {
        @JavascriptInterface public void start() { runOnUiThread(() -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION); return;
            }
            launchVoice();
        }); }
    }
    private void launchVoice() {
        try { Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell IOS SORT what to organise"); startActivityForResult(i, VOICE_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "Voice recognition is not available on this device", Toast.LENGTH_LONG).show(); }
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if (r==AUDIO_PERMISSION && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) launchVoice(); }
    @Override protected void onActivityResult(int r, int c, Intent d) { super.onActivityResult(r,c,d); if(r==VOICE_REQUEST && c==RESULT_OK && d!=null) { ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(a!=null&&!a.isEmpty()) { String v=org.json.JSONObject.quote(a.get(0)); web.evaluateJavascript("window.onNativeVoice("+v+")", null); } } }
    @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
